#include "veins/base/modules/BaseBattery.h"
